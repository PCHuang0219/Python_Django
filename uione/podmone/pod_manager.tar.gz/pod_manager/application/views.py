from django.shortcuts import render

# Create your views here.
from application import api 

def login(request): 
	return render(request, 'login.html')

def overview(request): 
	return render(request, 'index.html')

def components(request): 
	return render(request, 'components.html')

def system(request): 
	return render(request, 'system.html')

def page(request): 
	return render(request, 'page.html',
		{
			"power_zone" : api.get_rack_power() ,
			"thermal_zone" : api.get_rack_thermal()
		})

def switches(request): 
	return render(request, 'switches.html')

def racks(request): 
	return render(request, 'racks.html')

def storage(request): 
	return render(request, 'storage.html')

def nvme(request): 
	return render(request, 'nvme.html')

def blades(request): 
	return render(request, 'blades.html')
